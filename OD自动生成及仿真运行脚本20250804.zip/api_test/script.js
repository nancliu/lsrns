// API基础URL
// 使用相对路径，这样API请求会发送到提供页面的同一服务器
// const API_BASE_URL = 'http://127.0.0.1:7999';
const API_BASE_URL = '';

// API请求配置
const API_CONFIG = {
    baseUrl: 'http://127.0.0.1:7999',
    timeout: 120000, // 超时时间设置为120秒
    retryCount: 2    // 失败后重试次数
};

// DOM元素
document.addEventListener('DOMContentLoaded', () => {
    // 显示API连接信息
    const apiInfo = document.createElement('div');
    apiInfo.className = 'api-info';
    apiInfo.innerHTML = `
        <p><strong>API连接信息:</strong></p>
        <p>当前配置的API地址: ${API_CONFIG.baseUrl}</p>
        <p>请求超时时间: ${API_CONFIG.timeout/1000}秒</p>
        <p>请求重试次数: ${API_CONFIG.retryCount}次</p>
        <p>如需修改API配置，请编辑script.js文件中的API_CONFIG变量。</p>
    `;
    document.querySelector('.container').insertBefore(apiInfo, document.querySelector('.card'));
    
    // OD数据处理表单
    const odForm = document.getElementById('odForm');
    const processResult = document.getElementById('processResult');
    
    // 仿真运行表单
    const simulationForm = document.getElementById('simulationForm');
    const simulationResult = document.getElementById('simulationResult');
    
    // 处理OD数据表单提交
    odForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // 显示加载状态
        processResult.textContent = '处理中，请稍候...\n这可能需要几分钟时间，请耐心等待。';
        processResult.className = 'result-box show';
        
        // 获取表单数据
        const data = {
            start_time: document.getElementById('startTime').value,
            end_time: document.getElementById('endTime').value,
            taz_file: document.getElementById('tazFile').value,
            net_file: document.getElementById('netFile').value,
            interval_minutes: parseInt(document.getElementById('intervalMinutes').value),
            enable_mesoscopic: document.getElementById('enableMesoscopic').checked,
            output_summary: document.getElementById('outputSummary').checked,
            output_tripinfo: document.getElementById('outputTripinfo').checked,
            output_vehroute: document.getElementById('outputVehroute').checked,
            output_fcd: document.getElementById('outputFcd').checked,
            output_netstate: document.getElementById('outputNetstate').checked,
            output_emission: document.getElementById('outputEmission').checked
        };
        
        // 使用带超时和重试的API调用
        fetchWithTimeout(`${API_CONFIG.baseUrl}/process_od_data/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        }, API_CONFIG.timeout, API_CONFIG.retryCount)
        .then(async response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}, Text: ${await response.text()}`);
            }
            return response.json();
        })
        .then(result => {
            // 成功响应
            processResult.className = 'result-box show success';
            
            // 格式化显示结果
            const formattedResult = `✅ 处理成功！

运行文件夹: ${result.run_folder}
OD文件: ${result.od_file}
路由文件: ${result.route_file}
配置文件: ${result.sumocfg_file}

您可以使用这些信息填写下方的"运行仿真"表单。`;
            
            processResult.textContent = formattedResult;
            
            // 自动填充仿真表单
            document.getElementById('runFolder').value = result.run_folder;
            document.getElementById('odFile').value = result.od_file;
            document.getElementById('routeFile').value = result.route_file;
            document.getElementById('sumocfgFile').value = result.sumocfg_file;
        })
        .catch(error => {
            // 网络错误或其他异常
            processResult.className = 'result-box show error';
            processResult.textContent = `❌ 错误: ${error.message}\n\n可能的原因：
1. FastAPI服务器未运行
2. 数据库连接问题
3. 请求处理超时（处理大量数据时可能需要很长时间）

建议操作：
1. 检查FastAPI服务器是否正在运行
2. 尝试直接访问: http://127.0.0.1:7999/docs 检查API服务器
3. 尝试减小时间范围或增加时间间隔
4. 查看FastAPI服务器控制台输出是否有错误信息`;
        });
    });
    
    // 运行仿真表单提交
    simulationForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // 显示加载状态
        simulationResult.textContent = '正在启动仿真，请稍候...';
        simulationResult.className = 'result-box show';
        
        // 获取表单数据
        const data = {
            run_folder: document.getElementById('runFolder').value,
            od_file: document.getElementById('odFile').value,
            route_file: document.getElementById('routeFile').value,
            sumocfg_file: document.getElementById('sumocfgFile').value,
            gui: document.getElementById('guiMode').checked
        };
        
        // 使用带超时和重试的API调用
        fetchWithTimeout(`${API_CONFIG.baseUrl}/run_simulation/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        }, API_CONFIG.timeout, API_CONFIG.retryCount)
        .then(async response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}, Text: ${await response.text()}`);
            }
            return response.json();
        })
        .then(result => {
            simulationResult.className = 'result-box show success';
            
            // 根据是否使用GUI模式显示不同的成功消息
            if (result.status === "SUMO GUI launched") {
                simulationResult.textContent = `✅ SUMO GUI已启动！\n\n` +
                    `SUMO GUI正在运行中，请查看是否有新窗口打开。\n\n` +
                    `运行文件夹: ${result.run_folder}\n` +
                    `进程ID: ${result.pid}\n\n` +
                    `如果没有看到SUMO GUI窗口，请检查:\n` +
                    `1. SUMO是否正确安装\n` +
                    `2. 是否有足够的权限运行GUI应用\n` +
                    `3. 查看FastAPI服务器控制台输出是否有错误信息`;
            } else {
                simulationResult.textContent = `✅ 仿真已完成！\n\n${JSON.stringify(result, null, 2)}`;
            }
        })
        .catch(error => {
            simulationResult.className = 'result-box show error';
            simulationResult.textContent = `❌ 错误: ${error.message}\n\n可能的原因：
1. FastAPI服务器未运行
2. 仿真文件路径不正确
3. SUMO未正确安装或配置

建议操作：
1. 检查FastAPI服务器是否正在运行
2. 确认文件路径是否正确
3. 查看FastAPI服务器控制台输出是否有错误信息`;
        });
    });
});

/**
 * 带超时和重试的fetch函数
 * @param {string} url - 请求URL
 * @param {Object} options - fetch选项
 * @param {number} timeout - 超时时间(毫秒)
 * @param {number} retries - 重试次数
 * @returns {Promise} - fetch Promise
 */
async function fetchWithTimeout(url, options, timeout = 30000, retries = 1) {
    let currentTry = 0;
    
    async function attemptFetch() {
        currentTry++;
        
        // 创建一个可以被中止的控制器
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);
        
        try {
            const response = await fetch(url, {
                ...options,
                signal: controller.signal
            });
            clearTimeout(timeoutId);
            return response;
        } catch (error) {
            clearTimeout(timeoutId);
            
            if (error.name === 'AbortError') {
                throw new Error(`请求超时（${timeout/1000}秒）。处理大量数据时可能需要更长时间。`);
            }
            
            if (currentTry <= retries) {
                console.log(`请求失败，正在重试(${currentTry}/${retries})...`);
                return attemptFetch();
            }
            
            throw error;
        }
    }
    
    return attemptFetch();
} 